import click
from pathlib import Path
from rich.console import Console
from rich.table import Table
from rich.panel import Panel

from .loader import load_log
from .exporters.motec_exporter import MotecExporter
from .analyzers.slope_analyzer import (
    analyze_slope_stability,
    detect_oscillation_events,
    detect_singularities
)
from .analyzers.yaw_analyzer import (
    analyze_yaw_dynamics,
    analyze_clipping
)
from .analyzers.lateral_analyzer import analyze_lateral_dynamics
from .plots import (
    plot_slope_timeseries,
    plot_slip_vs_latg,
    plot_dalpha_histogram,
    plot_slope_correlation,
    plot_yaw_diagnostic,
    plot_system_health,
    plot_threshold_thrashing,
    plot_suspension_yaw_correlation,
    plot_bottoming_diagnostic,
    plot_yaw_fft,
    plot_clipping_components,
    plot_pull_detector,
    plot_unopposed_force,
    plot_lateral_diagnostic,
    plot_longitudinal_diagnostic,
    plot_raw_telemetry_health,
    plot_load_estimation_diagnostic
)
from .reports import generate_text_report

console = Console()

def _show_info(metadata, df):
    console.print(Panel.fit(
        f"[bold blue]Session Information[/bold blue]\n\n"
        f"Driver: {metadata.driver_name}\n"
        f"Vehicle: {metadata.vehicle_name} ({metadata.car_brand} {metadata.car_class})\n"
        f"Track: {metadata.track_name}\n"
        f"Duration: {df['Time'].max():.1f} seconds\n"
        f"Frames: {len(df)}\n"
        f"App Version: {metadata.app_version}",
        title="Log File Info"
    ))

def _run_analyze(metadata, df, verbose=False):
    # Run analyses
    slope_results = analyze_slope_stability(df)
    oscillations = detect_oscillation_events(df)
    singularity_count, worst_slope = detect_singularities(df)
    yaw_results = analyze_yaw_dynamics(df)
    clipping_results = analyze_clipping(df)
    lateral_results = analyze_lateral_dynamics(df, metadata)
    
    # Display results - Slope
    table = Table(title="Slope Detection Analysis")
    table.add_column("Metric", style="cyan")
    table.add_column("Value", style="green")
    table.add_column("Status", style="yellow")
    
    table.add_row(
        "Slope Std Dev",
        f"{slope_results['slope_std']:.2f}",
        "HIGH" if slope_results['slope_std'] > 5.0 else "OK"
    )
    table.add_row(
        "Slope Range",
        f"{slope_results['slope_min']:.1f} to {slope_results['slope_max']:.1f}",
        "WIDE" if (slope_results['slope_max'] - slope_results['slope_min']) > 20 else "OK"
    )
    
    if slope_results.get('active_percentage') is not None:
        table.add_row(
            "Active %",
            f"{slope_results['active_percentage']:.1f}%",
            "LOW" if slope_results['active_percentage'] < 30 else "OK"
        )
        
    if slope_results.get('floor_percentage') is not None:
        table.add_row(
            "Floor Hits",
            f"{slope_results['floor_percentage']:.1f}%",
            "HIGH" if slope_results['floor_percentage'] > 5 else "OK"
        )
        
    table.add_row(
        "Oscillation Events",
        str(len(oscillations)),
        "MANY" if len(oscillations) > 3 else "OK"
    )
    table.add_row(
        "Singularity Events",
        str(singularity_count),
        "CRITICAL" if singularity_count > 0 else "OK"
    )
    if singularity_count > 0:
        table.add_row(
            "Worst Singularity",
            f"{worst_slope:.1f}",
            "SEVERE" if worst_slope > 20.0 else "WARN"
        )
    
    console.print(table)
    
    # Display results - Yaw & Clipping
    table2 = Table(title="Yaw & Clipping Analysis")
    table2.add_column("Metric", style="cyan")
    table2.add_column("Value", style="green")
    table2.add_column("Status", style="yellow")

    if yaw_results.get('threshold_crossing_rate') is not None:
        table2.add_row(
            "Threshold Crossing Rate",
            f"{yaw_results['threshold_crossing_rate']:.2f} Hz",
            "HIGH" if yaw_results['threshold_crossing_rate'] > 5.0 else "OK"
        )
    if yaw_results.get('yaw_kick_contribution_pct') is not None:
        table2.add_row(
            "Yaw Kick Contribution",
            f"{yaw_results['yaw_kick_contribution_pct']:.1f}%",
            "HIGH" if yaw_results['yaw_kick_contribution_pct'] > 30.0 else "OK"
        )
    if clipping_results.get('total_clipping_pct') is not None:
        table2.add_row(
            "Total Clipping",
            f"{clipping_results['total_clipping_pct']:.1f}%",
            "HIGH" if clipping_results['total_clipping_pct'] > 10.0 else "OK"
        )

    console.print(table2)

    # Display results - Lateral Load
    table3 = Table(title="Lateral Load Analysis")
    table3.add_column("Metric", style="cyan")
    table3.add_column("Value", style="green")
    table3.add_column("Status", style="yellow")

    if lateral_results.get('load_transfer_correlation') is not None:
        table3.add_row(
            "Load Transfer Corr",
            f"{lateral_results['load_transfer_correlation']:.3f}",
            "LOW" if lateral_results['load_transfer_correlation'] < 0.8 else "OK"
        )
    if lateral_results.get('load_contribution_pct') is not None:
        table3.add_row(
            "Load Contribution",
            f"{lateral_results['load_contribution_pct']:.1f}%",
            "INFO"
        )
    if lateral_results.get('g_contribution_pct') is not None:
        table3.add_row(
            "G-Force Contribution",
            f"{lateral_results['g_contribution_pct']:.1f}%",
            "INFO"
        )

    console.print(table3)

    # Show issues
    all_issues = slope_results['issues'].copy()

    threshold_crossing_rate = yaw_results.get('threshold_crossing_rate')
    if threshold_crossing_rate is not None and threshold_crossing_rate > 5.0:
        all_issues.append(f"HIGH YAW THRASHING ({threshold_crossing_rate:.1f} Hz)")

    total_clipping = clipping_results.get('total_clipping_pct')
    if total_clipping is not None and total_clipping > 10.0:
        all_issues.append(f"HIGH CLIPPING ({total_clipping:.1f}%)")

    if all_issues:
        console.print("\n[bold red]Issues Detected:[/bold red]")
        for issue in all_issues:
            console.print(f"  • {issue}")
    else:
        console.print("\n[bold green]No significant issues detected.[/bold green]")

from rich.progress import Progress, SpinnerColumn, TextColumn

def _run_plots(metadata, df, output_dir, logfile_stem, plot_all=False):
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
        transient=True
    ) as progress:
        task = progress.add_task(f"Generating plots for {logfile_stem}...", total=None)
        
        def update_status(msg):
            progress.update(task, description=f" {logfile_stem}: {msg}")

        # Time series plot
        ts_path = output_path / f"{logfile_stem}_timeseries.png"
        plot_slope_timeseries(df, str(ts_path), show=False, status_callback=update_status)
        console.print(f"  [OK] Created: {ts_path}")
        
        if plot_all:
            # Tire curve
            tc_path = output_path / f"{logfile_stem}_tire_curve.png"
            plot_slip_vs_latg(df, str(tc_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {tc_path}")
            
            # dAlpha histogram
            hist_path = output_path / f"{logfile_stem}_dalpha_hist.png"
            plot_dalpha_histogram(df, str(hist_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {hist_path}")

            # Slope correlation
            corr_path = output_path / f"{logfile_stem}_slope_corr.png"
            plot_slope_correlation(df, str(corr_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {corr_path}")

            # Yaw Diagnostic
            yaw_path = output_path / f"{logfile_stem}_yaw_diag.png"
            plot_yaw_diagnostic(df, output_path=str(yaw_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {yaw_path}")

            # System Health
            health_path = output_path / f"{logfile_stem}_health.png"
            plot_system_health(df, str(health_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {health_path}")

            # FFT
            fft_path = output_path / f"{logfile_stem}_yaw_fft.png"
            plot_yaw_fft(df, str(fft_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {fft_path}")

            # Thrashing
            thrash_path = output_path / f"{logfile_stem}_yaw_thrashing.png"
            plot_threshold_thrashing(df, output_path=str(thrash_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {thrash_path}")

            # Suspension Correlation
            susp_path = output_path / f"{logfile_stem}_susp_corr.png"
            plot_suspension_yaw_correlation(df, str(susp_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {susp_path}")

            # Bottoming
            bottom_path = output_path / f"{logfile_stem}_bottoming.png"
            plot_bottoming_diagnostic(df, str(bottom_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {bottom_path}")

            # Clipping
            clip_path = output_path / f"{logfile_stem}_clipping.png"
            plot_clipping_components(df, str(clip_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {clip_path}")

            # Pull Detector
            pull_path = output_path / f"{logfile_stem}_pull_detector.png"
            plot_pull_detector(df, str(pull_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {pull_path}")

            # Unopposed Force
            unopposed_path = output_path / f"{logfile_stem}_unopposed.png"
            plot_unopposed_force(df, str(unopposed_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {unopposed_path}")

            # Lateral Diagnostic
            lat_path = output_path / f"{logfile_stem}_lateral_diag.png"
            plot_lateral_diagnostic(df, metadata, str(lat_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {lat_path}")

            # Longitudinal Diagnostic
            long_path = output_path / f"{logfile_stem}_longitudinal_diag.png"
            plot_longitudinal_diagnostic(df, metadata, str(long_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {long_path}")

            # Raw Telemetry Health
            health_raw_path = output_path / f"{logfile_stem}_raw_telemetry.png"
            plot_raw_telemetry_health(df, str(health_raw_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {health_raw_path}")

            # Load Estimation Diagnostic
            load_diag_path = output_path / f"{logfile_stem}_load_estimation.png"
            plot_load_estimation_diagnostic(df, str(load_diag_path), show=False, status_callback=update_status)
            console.print(f"  [OK] Created: {load_diag_path}")

@click.group()
@click.version_option(version='1.2.0')
def cli():
    """lmuFFB Log Analyzer - Analyze FFB telemetry logs for diagnostics."""
    pass

@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--export-csv', is_flag=True, help='Export data to CSV')
def info(logfile, export_csv):
    """Display session info from a log file."""
    try:
        metadata, df = load_log(logfile)
        _show_info(metadata, df)
        if export_csv:
            csv_path = Path(logfile).with_suffix('.csv')
            df.to_csv(csv_path, index=False)
            console.print(f"[bold green]Exported to:[/bold green] {csv_path}")
    except Exception as e:
        console.print(f"[bold red]Error loading log:[/bold red] {e}")

@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--verbose', '-v', is_flag=True, help='Show detailed output')
@click.option('--export-csv', is_flag=True, help='Export data to CSV')
def analyze(logfile, verbose, export_csv):
    """Analyze a log file and show summary."""
    console.print(f"[bold]Analyzing:[/bold] {logfile}")
    try:
        metadata, df = load_log(logfile)
        _run_analyze(metadata, df, verbose)
        if export_csv:
            csv_path = Path(logfile).with_suffix('.csv')
            df.to_csv(csv_path, index=False)
            console.print(f"[bold green]Exported to:[/bold green] {csv_path}")
    except Exception as e:
        console.print(f"[bold red]Error analyzing log:[/bold red] {e}")

@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--output', '-o', default='.', help='Output directory for plots')
@click.option('--all', 'plot_all', is_flag=True, help='Generate all plot types')
def plots(logfile, output, plot_all):
    """Generate diagnostic plots from a log file."""
    console.print(f"[bold]Generating plots for:[/bold] {logfile}")
    try:
        metadata, df = load_log(logfile)
        _run_plots(metadata, df, output, Path(logfile).stem, plot_all)
        console.print("\n[bold green]Done![/bold green]")
    except Exception as e:
        console.print(f"[bold red]Error generating plots:[/bold red] {e}")

@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--output', '-o', help='Output .ld file path')
@click.option('--freq', '-f', default=100, help='Resampling frequency in Hz (default 100)')
def export_motec(logfile, output, freq):
    """Export a log file to MoTeC i2 Pro format (.ld and .ldx)."""
    try:
        metadata, df = load_log(logfile)
        if not output:
            output = str(Path(logfile).with_suffix('.ld'))

        console.print(f"[bold]Exporting to MoTeC:[/bold] {output}")
        exporter = MotecExporter()
        exporter.export(metadata, df, output, target_freq=freq)
        console.print(f"[bold green]Successfully exported to:[/bold green] {output} and {Path(output).with_suffix('.ldx')}")
    except Exception as e:
        console.print(f"[bold red]Error exporting to MoTeC:[/bold red] {e}")

@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--output', '-o', help='Output file path')
def report(logfile, output):
    """Generate a full diagnostic report."""
    try:
        metadata, df = load_log(logfile)
        report_text = generate_text_report(metadata, df)
        
        if output:
            with open(output, 'w') as f:
                f.write(report_text)
            console.print(f"[bold green]Report saved to:[/bold green] {output}")
        else:
            console.print(report_text)
    except Exception as e:
        console.print(f"[bold red]Error generating report:[/bold red] {e}")

@cli.command()
@click.argument('logdir', type=click.Path(exists=True, file_okay=False, dir_okay=True))
@click.option('--output', '-o', default='analyzer_results', help='Output directory for batch results')
def batch(logdir, output):
    """Run all analysis commands for all log files in a directory."""
    log_path = Path(logdir)
    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)

    log_files = []
    for ext in ['*.bin', '*.csv']:
        log_files.extend(list(log_path.glob(ext)))

    if not log_files:
        # Try finding in subdirectories
        for ext in ['*.bin', '*.csv']:
            log_files.extend(list(log_path.rglob(ext)))

    log_files = sorted(log_files)

    if not log_files:
        console.print(f"[yellow]No .bin or .csv files found in {logdir}[/yellow]")
        return

    console.print(f"[bold green]Found {len(log_files)} log files. Starting batch processing...[/bold green]")

    for logfile in log_files:
        console.print(f"\n[bold blue]Processing: {logfile.name}[/bold blue]")
        try:
            # Load ONCE for all operations
            metadata, df = load_log(str(logfile))
            
            # 1. Info
            _show_info(metadata, df)
            
            # 2. Analyze
            _run_analyze(metadata, df)
            
            # 3. Plots
            _run_plots(metadata, df, output_path, logfile.stem, plot_all=True)
            
            # 4. Report
            report_file = output_path / f"{logfile.stem}_report.txt"
            report_text = generate_text_report(metadata, df)
            with open(report_file, 'w') as f:
                f.write(report_text)
            console.print(f"  [OK] Created: {report_file}")

        except Exception as e:
            console.print(f"[bold red]Error processing {logfile.name}:[/bold red] {e}")

    console.print(f"\n[bold green]Batch processing complete! Results saved to: {output}[/bold green]")
@cli.command()
@click.argument('logfile', type=click.Path(exists=True))
@click.option('--output', '-o', help='Output directory for results')
def analyze_full(logfile, output):
    """Run all analysis steps for a single log file (info, analyze, plots, report)."""
    log_path = Path(logfile)
    if not output:
        output = str(log_path.parent / f"analysis {log_path.stem}")
    
    output_path = Path(output)
    output_path.mkdir(parents=True, exist_ok=True)

    console.print(f"[bold blue]Processing: {log_path.name}[/bold blue]")
    try:
        # Load ONCE for all operations
        metadata, df = load_log(str(log_path))
        
        # 1. Info
        _show_info(metadata, df)
        
        # 2. Analyze
        _run_analyze(metadata, df)
        
        # 3. Plots
        _run_plots(metadata, df, output_path, log_path.stem, plot_all=True)
        
        # 4. Report
        report_file = output_path / f"{log_path.stem}_report.txt"
        report_text = generate_text_report(metadata, df)
        with open(report_file, 'w') as f:
            f.write(report_text)
        console.print(f"  [OK] Created: {report_file}")
        
        console.print(f"\n[bold green]Analysis complete! Results saved to: {output}[/bold green]")

    except Exception as e:
        console.print(f"[bold red]Error processing {log_path.name}:[/bold red] {e}")

if __name__ == '__main__':
    cli()
